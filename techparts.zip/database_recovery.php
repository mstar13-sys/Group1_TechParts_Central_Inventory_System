<?php
$appName = defined('APP_NAME') ? APP_NAME : 'TechParts POS';
$dbName = defined('DB_NAME') ? DB_NAME : 'TechParts2';
$dbUser = defined('DB_USER') ? DB_USER : 'root';
$projectRoot = __DIR__;
$backupDir = $projectRoot . DIRECTORY_SEPARATOR . 'database_backups';
$backupFiles = [];

if (is_dir($backupDir)) {
    foreach (glob($backupDir . DIRECTORY_SEPARATOR . '*.sql') ?: [] as $file) {
        if (is_file($file)) {
            $backupFiles[] = [
                'name' => basename($file),
                'path' => $file,
                'modified' => filemtime($file),
                'size' => filesize($file),
            ];
        }
    }
}

usort($backupFiles, static fn ($a, $b) => $b['modified'] <=> $a['modified']);

$latestBackup = $backupFiles[0] ?? null;
$backupPath = $latestBackup['path'] ?? ($backupDir . DIRECTORY_SEPARATOR . 'your_backup_file.sql');
$createCommand = 'mysql -u ' . $dbUser . ' -p -e "CREATE DATABASE IF NOT EXISTS ' . $dbName . ' CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci"';
$restoreCommand = 'mysql -u ' . $dbUser . ' -p ' . $dbName . ' < "' . $backupPath . '"';
$xamppCommand = 'C:\xampp\mysql\bin\mysql.exe -u ' . $dbUser . ' -p ' . $dbName . ' < "' . $backupPath . '"';

function recoveryFormatBytes(int $bytes): string
{
    if ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    }
    if ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    }
    return $bytes . ' B';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Database Recovery - <?= htmlspecialchars($appName) ?></title>
  <link rel="icon" href="/assets/images/logo.png" type="image/png">
  <style>
    :root {
      --bg: #0d0f14;
      --surface: #151820;
      --surface2: #1c2030;
      --surface3: #222840;
      --border: #2a3050;
      --accent: #f97316;
      --accent2: #3b82f6;
      --accent3: #22c55e;
      --danger: #ef4444;
      --warning: #eab308;
      --text: #e2e8f0;
      --text-muted: #8896b0;
      --radius: 10px;
      --shadow: 0 4px 24px rgba(0, 0, 0, .4);
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      min-height: 100vh;
      background: var(--bg);
      color: var(--text);
      font-family: "DM Sans", Arial, sans-serif;
      font-size: 14px;
      line-height: 1.5;
    }

    .recovery-shell {
      width: min(1040px, calc(100% - 32px));
      margin: 0 auto;
      padding: 32px 0;
    }

    .hero {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 24px;
      padding: 24px;
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      box-shadow: var(--shadow);
      margin-bottom: 18px;
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 12px;
      color: var(--accent);
      font-weight: 800;
      font-size: 18px;
      margin-bottom: 14px;
    }

    .brand img {
      width: 34px;
      height: 34px;
      border-radius: 8px;
      border: 1px solid var(--border);
      object-fit: cover;
    }

    h1 {
      font-size: 26px;
      line-height: 1.15;
      margin-bottom: 8px;
    }

    .muted {
      color: var(--text-muted);
    }

    .status-pill {
      white-space: nowrap;
      border: 1px solid rgba(239, 68, 68, .35);
      background: rgba(239, 68, 68, .1);
      color: var(--danger);
      border-radius: 999px;
      padding: 8px 12px;
      font-weight: 700;
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: .6px;
    }

    .grid {
      display: grid;
      grid-template-columns: 1.1fr .9fr;
      gap: 18px;
    }

    .card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 20px;
      margin-bottom: 18px;
    }

    .card-title {
      color: var(--text-muted);
      text-transform: uppercase;
      letter-spacing: .8px;
      font-size: 12px;
      font-weight: 800;
      margin-bottom: 14px;
    }

    .steps {
      display: grid;
      gap: 14px;
    }

    .step {
      display: grid;
      grid-template-columns: 34px 1fr;
      gap: 12px;
      align-items: start;
    }

    .step-number {
      width: 34px;
      height: 34px;
      border-radius: 8px;
      background: rgba(249, 115, 22, .14);
      color: var(--accent);
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-weight: 800;
    }

    .step strong {
      display: block;
      margin-bottom: 4px;
    }

    code,
    pre {
      font-family: Consolas, "Courier New", monospace;
    }

    pre {
      overflow-x: auto;
      background: var(--surface2);
      border: 1px solid var(--border);
      border-radius: 8px;
      color: var(--text);
      padding: 12px;
      margin-top: 8px;
      white-space: pre-wrap;
      word-break: break-word;
    }

    .note {
      border-left: 3px solid var(--warning);
      background: rgba(234, 179, 8, .08);
      padding: 12px 14px;
      border-radius: 8px;
      color: var(--text);
    }

    .file-list {
      display: grid;
      gap: 10px;
    }

    .file-item {
      padding: 12px;
      background: var(--surface2);
      border: 1px solid var(--border);
      border-radius: 8px;
    }

    .file-name {
      font-weight: 700;
      word-break: break-word;
    }

    .file-meta {
      margin-top: 4px;
      color: var(--text-muted);
      font-size: 12px;
    }

    .actions {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-top: 16px;
    }

    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      border-radius: 8px;
      padding: 9px 14px;
      text-decoration: none;
      border: 1px solid var(--border);
      color: var(--text);
      background: var(--surface2);
      font-weight: 700;
    }

    .btn-primary {
      background: var(--accent);
      border-color: var(--accent);
      color: #fff;
    }

    @media (max-width: 820px) {
      .hero,
      .grid {
        display: block;
      }

      .status-pill {
        display: inline-flex;
        margin-top: 16px;
      }
    }
  </style>
</head>
<body>
  <main class="recovery-shell">
    <section class="hero">
      <div>
        <div class="brand">
          <img src="/assets/images/logo.png" alt="">
          <span><?= htmlspecialchars($appName) ?></span>
        </div>
        <h1>Database Connection Problem</h1>
        <p class="muted">The system cannot connect to <strong><?= htmlspecialchars($dbName) ?></strong>. Use the steps below to restore the database from a SQL backup.</p>
      </div>
      <div class="status-pill">Database Down</div>
    </section>

    <div class="grid">
      <section>
        <div class="card">
          <div class="card-title">Recommended Recovery Steps</div>
          <div class="steps">
            <div class="step">
              <span class="step-number">1</span>
              <div>
                <strong>Start MySQL</strong>
                <p class="muted">Open XAMPP or your MySQL service manager and make sure MySQL is running.</p>
              </div>
            </div>

            <div class="step">
              <span class="step-number">2</span>
              <div>
                <strong>Open Command Prompt</strong>
                <p class="muted">Run CMD on the computer where MySQL is installed.</p>
              </div>
            </div>

            <div class="step">
              <span class="step-number">3</span>
              <div>
                <strong>Create the database if it was deleted</strong>
                <pre><?= htmlspecialchars($createCommand) ?></pre>
              </div>
            </div>

            <div class="step">
              <span class="step-number">4</span>
              <div>
                <strong>Restore the latest SQL backup</strong>
                <pre><?= htmlspecialchars($restoreCommand) ?></pre>
                <p class="muted">If MySQL is not available in CMD, use the XAMPP full path:</p>
                <pre><?= htmlspecialchars($xamppCommand) ?></pre>
              </div>
            </div>

            <div class="step">
              <span class="step-number">5</span>
              <div>
                <strong>Refresh the system</strong>
                <p class="muted">After the restore finishes, open the login page again and sign in as Admin.</p>
              </div>
            </div>
          </div>
        </div>

        <div class="card">
          <div class="card-title">phpMyAdmin Option</div>
          <p class="muted">You can also open phpMyAdmin, create/select <strong><?= htmlspecialchars($dbName) ?></strong>, choose Import, then upload one of the SQL files from <strong>database_backups</strong>.</p>
        </div>
      </section>

      <aside>
        <div class="card">
          <div class="card-title">Detected Backup Files</div>
          <?php if (empty($backupFiles)): ?>
            <p class="muted">No SQL backups were found in database_backups.</p>
          <?php else: ?>
            <div class="file-list">
              <?php foreach (array_slice($backupFiles, 0, 6) as $file): ?>
                <div class="file-item">
                  <div class="file-name"><?= htmlspecialchars($file['name']) ?></div>
                  <div class="file-meta">
                    <?= date('M d, Y g:i A', (int) $file['modified']) ?> · <?= recoveryFormatBytes((int) $file['size']) ?>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>

        <div class="card">
          <div class="card-title">Important</div>
          <div class="note">
            Restoring a SQL backup can replace current database data. Use the newest trusted backup file unless your admin specifically needs an older copy.
          </div>
          <div class="actions">
            <a class="btn btn-primary" href="/pages/login.php">Try Login Again</a>
            <a class="btn" href="/">Go to Start</a>
          </div>
        </div>
      </aside>
    </div>
  </main>
</body>
</html>
