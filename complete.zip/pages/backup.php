<?php
// pages/backup.php
require_once __DIR__ . '/../includes/config.php';
requireLogin(['Admin']);
$pageTitle = 'Backup & Recovery';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'create_backup') {
        $result = createDatabaseBackup('manual');
        setFlash($result['ok'] ? 'success' : 'danger', $result['message'], $result['ok'] ? 'Backup Complete' : 'Backup Failed');
        header('Location: /pages/backup.php');
        exit;
    }

    if ($action === 'restore_backup') {
        $type = $_POST['type'] ?? '';
        $name = $_POST['file'] ?? '';
        $result = restoreDatabaseBackup($type, $name);
        setFlash($result['ok'] ? 'success' : 'danger', $result['message'], $result['ok'] ? 'Recovery Complete' : 'Recovery Failed');
        header('Location: /pages/backup.php');
        exit;
    }

    if ($action === 'restore_latest') {
        $result = restoreLatestDatabaseBackup('manual_restore_latest');
        setFlash($result['ok'] ? 'success' : 'danger', $result['message'], $result['ok'] ? 'Latest Backup Restored' : 'Recovery Failed');
        header('Location: /pages/backup.php');
        exit;
    }
}

if (isset($_GET['download'], $_GET['type'])) {
    $file = findBackupFile((string) $_GET['type'], (string) $_GET['download']);
    if ($file === null) {
        http_response_code(404);
        exit('Backup file not found.');
    }

    header('Content-Type: application/sql');
    header('Content-Disposition: attachment; filename="' . basename($file) . '"');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    exit;
}

$backupFiles = listBackupFiles();
$manualCount = count(array_filter($backupFiles, fn($f) => $f['type'] === 'manual'));
$automaticCount = count(array_filter($backupFiles, fn($f) => $f['type'] === 'automatic'));
$lastRun = is_file(BACKUP_MARKER_FILE) ? trim((string) file_get_contents(BACKUP_MARKER_FILE)) : 'Never';
$history = readBackupHistory();

include __DIR__ . '/../includes/header.php';
?>

<div class="stat-grid">
  <div class="stat-card green">
    <div class="stat-label">Manual Backups</div>
    <div class="stat-value"><?= $manualCount ?></div>
    <div class="stat-sub">Stored in backups/manual</div>
  </div>
  <div class="stat-card blue">
    <div class="stat-label">Automatic Backups</div>
    <div class="stat-value"><?= $automaticCount ?></div>
    <div class="stat-sub">Stored in backups/automatic</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Last Daily Run</div>
    <div class="stat-value" style="font-size:20px"><?= htmlspecialchars($lastRun) ?></div>
    <div class="stat-sub">Auto recovery uses the newest backup</div>
  </div>
</div>

<div class="card">
  <div class="card-title">Create Manual Backup</div>
  <form method="POST" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
    <?= csrfField() ?>
    <input type="hidden" name="action" value="create_backup">
    <button type="submit" class="btn btn-primary">Create Backup Now</button>
    <span style="color:var(--text-muted);font-size:13px">Uses mysqldump with the database credentials from includes/config.php.</span>
  </form>
</div>

<div class="alert alert-info">
  If the system cannot connect to the database, it will try to restore the newest backup once. Admins can still restore any backup manually here.
</div>

<div class="card">
  <div class="card-title">Restore Latest Backup</div>
  <form method="POST" onsubmit="return confirm('Restore the newest backup? Current database data will be replaced.');" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
    <?= csrfField() ?>
    <input type="hidden" name="action" value="restore_latest">
    <button type="submit" class="btn btn-danger">Restore Latest Backup</button>
    <span style="color:var(--text-muted);font-size:13px">Automatically selects the newest file from manual and automatic backups.</span>
  </form>
</div>

<div class="card">
  <div class="card-title">Backup Files</div>
  <?php if (empty($backupFiles)): ?>
    <div class="empty-state">
      <p>No backup files yet.</p>
    </div>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>File</th>
            <th>Type</th>
            <th>Size</th>
            <th>Created</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($backupFiles as $file): ?>
            <tr>
              <td style="font-weight:600"><?= htmlspecialchars($file['name']) ?></td>
              <td><span class="badge badge-<?= $file['type'] === 'manual' ? 'orange' : 'blue' ?>"><?= htmlspecialchars($file['type']) ?></span></td>
              <td><?= formatBackupSize((int) $file['size']) ?></td>
              <td><?= date('M d, Y h:i A', (int) $file['created']) ?></td>
              <td style="display:flex;gap:8px;flex-wrap:wrap">
                <a class="btn btn-sm btn-ghost" href="/pages/backup.php?type=<?= urlencode($file['type']) ?>&download=<?= urlencode($file['name']) ?>">Download</a>
                <form method="POST" onsubmit="return confirm('Restore this backup? Current database data will be replaced.');">
                  <?= csrfField() ?>
                  <input type="hidden" name="action" value="restore_backup">
                  <input type="hidden" name="type" value="<?= htmlspecialchars($file['type']) ?>">
                  <input type="hidden" name="file" value="<?= htmlspecialchars($file['name']) ?>">
                  <button type="submit" class="btn btn-sm btn-danger">Restore</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-title">Backup History</div>
  <?php if (empty($history)): ?>
    <div class="empty-state">
      <p>No backup history yet.</p>
    </div>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>User</th>
            <th>Action</th>
            <th>Status</th>
            <th>File</th>
            <th>Message</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($history as $item): ?>
            <tr>
              <td><?= htmlspecialchars($item['date'] ?? '') ?></td>
              <td><?= htmlspecialchars($item['user'] ?? 'System') ?></td>
              <td><?= htmlspecialchars(str_replace('_', ' ', $item['action'] ?? '')) ?></td>
              <td><span class="badge badge-<?= ($item['status'] ?? '') === 'success' ? 'green' : 'red' ?>"><?= htmlspecialchars($item['status'] ?? '') ?></span></td>
              <td><?= htmlspecialchars($item['file'] ?? '') ?></td>
              <td style="color:var(--text-muted)"><?= htmlspecialchars($item['message'] ?? '') ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
