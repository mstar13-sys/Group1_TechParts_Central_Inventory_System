<?php
// automatic_backup/daily_backup.php
require_once __DIR__ . '/../includes/config.php';

runDailyAutomaticBackup();

echo 'Daily backup check complete.';
