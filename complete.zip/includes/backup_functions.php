<?php
// /includes/backup_functions.php

// Backup folders
const BACKUP_ROOT = __DIR__ . '/../backups';
const AUTO_BACKUP_DIR = BACKUP_ROOT . '/automatic';
const MANUAL_BACKUP_DIR = BACKUP_ROOT . '/manual';
const BACKUP_LOG_FILE = BACKUP_ROOT . '/backup_history.log';
const BACKUP_MARKER_FILE = AUTO_BACKUP_DIR . '/last_backup.txt';

function createBackupFolders(): void
{
    if (!is_dir(AUTO_BACKUP_DIR)) {
        mkdir(AUTO_BACKUP_DIR, 0775, true);
    }

    if (!is_dir(MANUAL_BACKUP_DIR)) {
        mkdir(MANUAL_BACKUP_DIR, 0775, true);
    }
}

function getMysqlCommand(string $commandName): string
{
    // If mysql and mysqldump are not in PATH, set MYSQL_BIN_PATH in config.php.
    if (defined('MYSQL_BIN_PATH') && MYSQL_BIN_PATH !== '') {
        return rtrim(MYSQL_BIN_PATH, "\\/") . DIRECTORY_SEPARATOR . $commandName;
    }

    return $commandName;
}

function getMysqlPassword(): string
{
    return DB_PASS === '' ? '' : ' --password=' . escapeshellarg(DB_PASS);
}

function saveBackupLog(string $action, string $status, string $file, string $message): void
{
    createBackupFolders();

    $user = currentUser();
    $log = [
        'date' => date('Y-m-d H:i:s'),
        'user' => $user['name'] ?? 'System',
        'action' => $action,
        'status' => $status,
        'file' => basename($file),
        'message' => $message,
    ];

    file_put_contents(BACKUP_LOG_FILE, json_encode($log) . PHP_EOL, FILE_APPEND | LOCK_EX);
}

function createDatabaseBackup(string $type = 'manual'): array
{
    createBackupFolders();

    $folder = $type === 'automatic' ? AUTO_BACKUP_DIR : MANUAL_BACKUP_DIR;
    $backupFile = $folder . '/' . DB_NAME . '_' . $type . '_' . date('Y-m-d_H-i-s') . '.sql';

    // Backup command
    $command = getMysqlCommand('mysqldump')
        . ' --host=' . escapeshellarg(DB_HOST)
        . ' --user=' . escapeshellarg(DB_USER)
        . getMysqlPassword()
        . ' --single-transaction '
        . escapeshellarg(DB_NAME)
        . ' > ' . escapeshellarg($backupFile);

    // Execute backup
    system($command, $result);

    if ($result === 0 && is_file($backupFile) && filesize($backupFile) > 0) {
        saveBackupLog($type . '_backup', 'success', $backupFile, 'Backup created.');
        return ['ok' => true, 'message' => 'Backup created successfully.'];
    }

    if (is_file($backupFile) && filesize($backupFile) === 0) {
        unlink($backupFile);
    }

    saveBackupLog($type . '_backup', 'failed', $backupFile, 'Backup failed.');
    return ['ok' => false, 'message' => 'Backup failed. Check mysqldump, MySQL credentials, and PATH.'];
}

function runDailyAutomaticBackup(): void
{
    createBackupFolders();

    $today = date('Y-m-d');
    $lastBackupDate = is_file(BACKUP_MARKER_FILE) ? trim(file_get_contents(BACKUP_MARKER_FILE)) : '';

    if ($lastBackupDate === $today) {
        return;
    }

    createDatabaseBackup('automatic');
    file_put_contents(BACKUP_MARKER_FILE, $today, LOCK_EX);
}

function findBackupFile(string $type, string $filename): ?string
{
    if ($type !== 'manual' && $type !== 'automatic') {
        return null;
    }

    if (basename($filename) !== $filename) {
        return null;
    }

    $folder = $type === 'automatic' ? AUTO_BACKUP_DIR : MANUAL_BACKUP_DIR;
    $backupFile = $folder . '/' . $filename;

    return is_file($backupFile) ? $backupFile : null;
}

function createDatabaseBeforeRestore(): bool
{
    $databaseName = str_replace('`', '``', DB_NAME);

    // Create database first, in case the whole database was deleted.
    $command = getMysqlCommand('mysql')
        . ' --host=' . escapeshellarg(DB_HOST)
        . ' --user=' . escapeshellarg(DB_USER)
        . getMysqlPassword()
        . ' --execute=' . escapeshellarg("CREATE DATABASE IF NOT EXISTS `$databaseName` CHARACTER SET utf8mb4");

    system($command, $result);
    return $result === 0;
}

function restoreDatabaseBackup(string $type, string $filename): array
{
    $backupFile = findBackupFile($type, $filename);

    if ($backupFile === null) {
        return ['ok' => false, 'message' => 'Backup file was not found.'];
    }

    if (!createDatabaseBeforeRestore()) {
        saveBackupLog('restore', 'failed', $backupFile, 'Cannot create database before restore.');
        return ['ok' => false, 'message' => 'Cannot create database before restore.'];
    }

    // Restore command
    $command = getMysqlCommand('mysql')
        . ' --host=' . escapeshellarg(DB_HOST)
        . ' --user=' . escapeshellarg(DB_USER)
        . getMysqlPassword()
        . ' ' . escapeshellarg(DB_NAME)
        . ' < ' . escapeshellarg($backupFile);

    // Execute restore
    system($command, $result);

    if ($result === 0) {
        saveBackupLog('restore', 'success', $backupFile, 'Database restored.');
        return ['ok' => true, 'message' => 'Database restored successfully.'];
    }

    saveBackupLog('restore', 'failed', $backupFile, 'Restore failed.');
    return ['ok' => false, 'message' => 'Restore failed. Check mysql, MySQL credentials, and PATH.'];
}

function listBackupFiles(): array
{
    createBackupFolders();
    $files = [];

    foreach (['manual', 'automatic'] as $type) {
        $folder = $type === 'automatic' ? AUTO_BACKUP_DIR : MANUAL_BACKUP_DIR;

        foreach (glob($folder . '/*.sql') ?: [] as $file) {
            $files[] = [
                'type' => $type,
                'name' => basename($file),
                'size' => filesize($file),
                'created' => filemtime($file),
            ];
        }
    }

    usort($files, fn($a, $b) => $b['created'] <=> $a['created']);
    return $files;
}

function restoreLatestDatabaseBackup(string $action = 'restore_latest'): array
{
    $files = listBackupFiles();

    if (empty($files)) {
        return ['ok' => false, 'message' => 'No backup file is available.'];
    }

    $latestBackup = $files[0];
    $result = restoreDatabaseBackup($latestBackup['type'], $latestBackup['name']);

    saveBackupLog($action, $result['ok'] ? 'success' : 'failed', $latestBackup['name'], $result['message']);
    return $result;
}

function readBackupHistory(int $limit = 50): array
{
    if (!is_file(BACKUP_LOG_FILE)) {
        return [];
    }

    $history = [];
    $lines = array_reverse(file(BACKUP_LOG_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES));

    foreach ($lines as $line) {
        $log = json_decode($line, true);

        if (is_array($log)) {
            $history[] = $log;
        }

        if (count($history) >= $limit) {
            break;
        }
    }

    return $history;
}

function formatBackupSize(int $bytes): string
{
    if ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    }

    return number_format($bytes / 1024, 2) . ' KB';
}
