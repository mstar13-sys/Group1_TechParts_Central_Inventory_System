<?php
header('Location: /pages/forgot_password.php');
exit;
